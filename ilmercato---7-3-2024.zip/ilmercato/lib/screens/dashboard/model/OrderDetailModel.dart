/// status : "200"
/// data : {"records":[{"order_no":"3","login_id":"69","d_id":"1","grand_total":"78438","sub_time":"16:06:02","status":"Placed","sub_date":"20-06-2022","dname":"sudh","de_country":"india","de_add":"822","de_city":"kanpur","de_mob":"9560995542","de_email":"sudgupta819@gmail.com","de_pincode":"208001","dealer_name":"Dealer ","dealer_mob":"8797989898","dealer_add":"addres","dealer_state":"Uttar Pradesh","dealer_city":"Kanpur","dealer_pincode":"208001"}]}
/// products : {"records1":[{"sub_weight":"10.00","sub_purity":"18","sub_purity_value":"78","sub_qty":"1","sub_price":"47483.00","sub_total_price":"41464.80","pname":"Bangles"},{"sub_weight":"8.00","sub_purity":"18","sub_purity_value":"78","sub_qty":"1","sub_price":"38007.00","sub_total_price":"33171.84","pname":"Bangles 2"}]}
/// message : " Successfully Done"

class OrderDetailModel {
  OrderDetailModel({
      String? status, 
      Data? data, 
      Products? products, 
      String? message,}){
    _status = status;
    _data = data;
    _products = products;
    _message = message;
}

  OrderDetailModel.fromJson(dynamic json) {
    _status = json['status'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
    _products = json['products'] != null ? Products.fromJson(json['products']) : null;
    _message = json['message'];
  }
  String? _status;
  Data? _data;
  Products? _products;
  String? _message;
OrderDetailModel copyWith({  String? status,
  Data? data,
  Products? products,
  String? message,
}) => OrderDetailModel(  status: status ?? _status,
  data: data ?? _data,
  products: products ?? _products,
  message: message ?? _message,
);
  String? get status => _status;
  Data? get data => _data;
  Products? get products => _products;
  String? get message => _message;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.toJson();
    }
    if (_products != null) {
      map['products'] = _products?.toJson();
    }
    map['message'] = _message;
    return map;
  }

}

/// records1 : [{"sub_weight":"10.00","sub_purity":"18","sub_purity_value":"78","sub_qty":"1","sub_price":"47483.00","sub_total_price":"41464.80","pname":"Bangles"},{"sub_weight":"8.00","sub_purity":"18","sub_purity_value":"78","sub_qty":"1","sub_price":"38007.00","sub_total_price":"33171.84","pname":"Bangles 2"}]

class Products {
  Products({
      List<Records1>? records1,}){
    _records1 = records1;
}

  Products.fromJson(dynamic json) {
    if (json['records1'] != null) {
      _records1 = [];
      json['records1'].forEach((v) {
        _records1?.add(Records1.fromJson(v));
      });
    }
  }
  List<Records1>? _records1;
Products copyWith({  List<Records1>? records1,
}) => Products(  records1: records1 ?? _records1,
);
  List<Records1>? get records1 => _records1;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_records1 != null) {
      map['records1'] = _records1?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// sub_weight : "10.00"
/// sub_purity : "18"
/// sub_purity_value : "78"
/// sub_qty : "1"
/// sub_price : "47483.00"
/// sub_total_price : "41464.80"
/// pname : "Bangles"

class Records1 {
  Records1({
      String? subWeight, 
      String? subPurity, 
      String? subPurityValue, 
      String? subQty, 
      String? subPrice, 
      String? subTotalPrice, 
      String? pname,}){
    _subWeight = subWeight;
    _subPurity = subPurity;
    _subPurityValue = subPurityValue;
    _subQty = subQty;
    _subPrice = subPrice;
    _subTotalPrice = subTotalPrice;
    _pname = pname;
}

  Records1.fromJson(dynamic json) {
    _subWeight = json['sub_weight'];
    _subPurity = json['sub_purity'];
    _subPurityValue = json['sub_purity_value'];
    _subQty = json['sub_qty'];
    _subPrice = json['sub_price'];
    _subTotalPrice = json['sub_total_price'];
    _pname = json['pname'];
  }
  String? _subWeight;
  String? _subPurity;
  String? _subPurityValue;
  String? _subQty;
  String? _subPrice;
  String? _subTotalPrice;
  String? _pname;
Records1 copyWith({  String? subWeight,
  String? subPurity,
  String? subPurityValue,
  String? subQty,
  String? subPrice,
  String? subTotalPrice,
  String? pname,
}) => Records1(  subWeight: subWeight ?? _subWeight,
  subPurity: subPurity ?? _subPurity,
  subPurityValue: subPurityValue ?? _subPurityValue,
  subQty: subQty ?? _subQty,
  subPrice: subPrice ?? _subPrice,
  subTotalPrice: subTotalPrice ?? _subTotalPrice,
  pname: pname ?? _pname,
);
  String? get subWeight => _subWeight;
  String? get subPurity => _subPurity;
  String? get subPurityValue => _subPurityValue;
  String? get subQty => _subQty;
  String? get subPrice => _subPrice;
  String? get subTotalPrice => _subTotalPrice;
  String? get pname => _pname;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['sub_weight'] = _subWeight;
    map['sub_purity'] = _subPurity;
    map['sub_purity_value'] = _subPurityValue;
    map['sub_qty'] = _subQty;
    map['sub_price'] = _subPrice;
    map['sub_total_price'] = _subTotalPrice;
    map['pname'] = _pname;
    return map;
  }

}

/// records : [{"order_no":"3","login_id":"69","d_id":"1","grand_total":"78438","sub_time":"16:06:02","status":"Placed","sub_date":"20-06-2022","dname":"sudh","de_country":"india","de_add":"822","de_city":"kanpur","de_mob":"9560995542","de_email":"sudgupta819@gmail.com","de_pincode":"208001","dealer_name":"Dealer ","dealer_mob":"8797989898","dealer_add":"addres","dealer_state":"Uttar Pradesh","dealer_city":"Kanpur","dealer_pincode":"208001"}]

class Data {
  Data({
      List<Records>? records,}){
    _records = records;
}

  Data.fromJson(dynamic json) {
    if (json['records'] != null) {
      _records = [];
      json['records'].forEach((v) {
        _records?.add(Records.fromJson(v));
      });
    }
  }
  List<Records>? _records;
Data copyWith({  List<Records>? records,
}) => Data(  records: records ?? _records,
);
  List<Records>? get records => _records;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_records != null) {
      map['records'] = _records?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

/// order_no : "3"
/// login_id : "69"
/// d_id : "1"
/// grand_total : "78438"
/// sub_time : "16:06:02"
/// status : "Placed"
/// sub_date : "20-06-2022"
/// dname : "sudh"
/// de_country : "india"
/// de_add : "822"
/// de_city : "kanpur"
/// de_mob : "9560995542"
/// de_email : "sudgupta819@gmail.com"
/// de_pincode : "208001"
/// dealer_name : "Dealer "
/// dealer_mob : "8797989898"
/// dealer_add : "addres"
/// dealer_state : "Uttar Pradesh"
/// dealer_city : "Kanpur"
/// dealer_pincode : "208001"

class Records {
  Records({
      String? orderNo, 
      String? loginId, 
      String? dId, 
      String? grandTotal, 
      String? subTime, 
      String? status, 
      String? subDate, 
      String? dname, 
      String? deCountry, 
      String? deAdd, 
      String? deCity, 
      String? deMob, 
      String? deEmail, 
      String? dePincode, 
      String? dealerName, 
      String? dealerMob, 
      String? dealerAdd, 
      String? dealerState, 
      String? dealerCity, 
      String? dealerPincode,}){
    _orderNo = orderNo;
    _loginId = loginId;
    _dId = dId;
    _grandTotal = grandTotal;
    _subTime = subTime;
    _status = status;
    _subDate = subDate;
    _dname = dname;
    _deCountry = deCountry;
    _deAdd = deAdd;
    _deCity = deCity;
    _deMob = deMob;
    _deEmail = deEmail;
    _dePincode = dePincode;
    _dealerName = dealerName;
    _dealerMob = dealerMob;
    _dealerAdd = dealerAdd;
    _dealerState = dealerState;
    _dealerCity = dealerCity;
    _dealerPincode = dealerPincode;
}

  Records.fromJson(dynamic json) {
    _orderNo = json['order_no'];
    _loginId = json['login_id'];
    _dId = json['d_id'];
    _grandTotal = json['grand_total'];
    _subTime = json['sub_time'];
    _status = json['status'];
    _subDate = json['sub_date'];
    _dname = json['dname'];
    _deCountry = json['de_country'];
    _deAdd = json['de_add'];
    _deCity = json['de_city'];
    _deMob = json['de_mob'];
    _deEmail = json['de_email'];
    _dePincode = json['de_pincode'];
    _dealerName = json['dealer_name'];
    _dealerMob = json['dealer_mob'];
    _dealerAdd = json['dealer_add'];
    _dealerState = json['dealer_state'];
    _dealerCity = json['dealer_city'];
    _dealerPincode = json['dealer_pincode'];
  }
  String? _orderNo;
  String? _loginId;
  String? _dId;
  String? _grandTotal;
  String? _subTime;
  String? _status;
  String? _subDate;
  String? _dname;
  String? _deCountry;
  String? _deAdd;
  String? _deCity;
  String? _deMob;
  String? _deEmail;
  String? _dePincode;
  String? _dealerName;
  String? _dealerMob;
  String? _dealerAdd;
  String? _dealerState;
  String? _dealerCity;
  String? _dealerPincode;
Records copyWith({  String? orderNo,
  String? loginId,
  String? dId,
  String? grandTotal,
  String? subTime,
  String? status,
  String? subDate,
  String? dname,
  String? deCountry,
  String? deAdd,
  String? deCity,
  String? deMob,
  String? deEmail,
  String? dePincode,
  String? dealerName,
  String? dealerMob,
  String? dealerAdd,
  String? dealerState,
  String? dealerCity,
  String? dealerPincode,
}) => Records(  orderNo: orderNo ?? _orderNo,
  loginId: loginId ?? _loginId,
  dId: dId ?? _dId,
  grandTotal: grandTotal ?? _grandTotal,
  subTime: subTime ?? _subTime,
  status: status ?? _status,
  subDate: subDate ?? _subDate,
  dname: dname ?? _dname,
  deCountry: deCountry ?? _deCountry,
  deAdd: deAdd ?? _deAdd,
  deCity: deCity ?? _deCity,
  deMob: deMob ?? _deMob,
  deEmail: deEmail ?? _deEmail,
  dePincode: dePincode ?? _dePincode,
  dealerName: dealerName ?? _dealerName,
  dealerMob: dealerMob ?? _dealerMob,
  dealerAdd: dealerAdd ?? _dealerAdd,
  dealerState: dealerState ?? _dealerState,
  dealerCity: dealerCity ?? _dealerCity,
  dealerPincode: dealerPincode ?? _dealerPincode,
);
  String? get orderNo => _orderNo;
  String? get loginId => _loginId;
  String? get dId => _dId;
  String? get grandTotal => _grandTotal;
  String? get subTime => _subTime;
  String? get status => _status;
  String? get subDate => _subDate;
  String? get dname => _dname;
  String? get deCountry => _deCountry;
  String? get deAdd => _deAdd;
  String? get deCity => _deCity;
  String? get deMob => _deMob;
  String? get deEmail => _deEmail;
  String? get dePincode => _dePincode;
  String? get dealerName => _dealerName;
  String? get dealerMob => _dealerMob;
  String? get dealerAdd => _dealerAdd;
  String? get dealerState => _dealerState;
  String? get dealerCity => _dealerCity;
  String? get dealerPincode => _dealerPincode;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['order_no'] = _orderNo;
    map['login_id'] = _loginId;
    map['d_id'] = _dId;
    map['grand_total'] = _grandTotal;
    map['sub_time'] = _subTime;
    map['status'] = _status;
    map['sub_date'] = _subDate;
    map['dname'] = _dname;
    map['de_country'] = _deCountry;
    map['de_add'] = _deAdd;
    map['de_city'] = _deCity;
    map['de_mob'] = _deMob;
    map['de_email'] = _deEmail;
    map['de_pincode'] = _dePincode;
    map['dealer_name'] = _dealerName;
    map['dealer_mob'] = _dealerMob;
    map['dealer_add'] = _dealerAdd;
    map['dealer_state'] = _dealerState;
    map['dealer_city'] = _dealerCity;
    map['dealer_pincode'] = _dealerPincode;
    return map;
  }

}