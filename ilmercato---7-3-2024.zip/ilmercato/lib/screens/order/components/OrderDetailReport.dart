import 'package:flutter/material.dart';
import 'package:ilmercato/constants.dart';
import 'package:ilmercato/screens/dashboard/model/OrderDetailModel.dart';


class OrderDetailReport extends StatelessWidget {
 final Products product;
  final Records order;
  const OrderDetailReport({Key? key,required this.product,required this.order}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(width: 1,color: kDarkTextColor)
          ),
          child: SingleChildScrollView(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 15.0),
                  child: Row(
                    children: [
                      Text("Order No. ${order.orderNo}",style: listText,),
                      Spacer(),
                      Text("Date: ${order.subDate}",style: listText,),

                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10.0,vertical: 10.0),
                  child: Row(
                    children: [
                      Text("Order Status :  ${order.status}",style: listText,),
                      Spacer(),
                      Text("Time: ${order.subTime}",style: listText,),
                    ],
                  ),
                ),
                Divider(thickness: 2,color: kDarkTextColor,),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width*1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Text("Shipping To",style: headingStyle,),
                        SizedBox(height: 10,),
                        Text("${order.dname}",style: listText,),
                        Text("${order.deAdd}, ${order.deCity},",style: largeListText,),
                        Text("${order.deCountry} - ${order.dePincode},",style: largeListText,),
                        Text("Mobile:  ${order.deMob}",style: largeListText,),
                        Text("Email Id:  ${order.deEmail}",style: largeListText,),
                      ],
                    ),
                  ),
                ),
                Divider(thickness: 2,color: kDarkTextColor,),
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width*1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,

                      children: [
                        Text("Dealer To",style: headingStyle,),
                        SizedBox(height: 10,),
                        Text("${order.dealerName}",style: listText,),
                        Text("${order.dealerAdd}, ${order.dealerCity},",style: largeListText,),
                        Text("${order.dealerState} - ${order.dealerPincode},",style: largeListText,),
                        Text("Mobile:  ${order.dealerMob}",style: largeListText,),
                      //  Text("${order}",style: largeListText,),
                      ],
                    ),
                  ),
                ),
                Divider(thickness: 2,color: kDarkTextColor,),
                Column(
                  children: [

                    Container(
                      height: 35,
                      child: ListTile(
                        title: Text("Product Description",style: listText,),
                        trailing: Text("Rate",style: listText,),
                      ),
                    ),

                   Divider(thickness: 1,color: kDarkTextColor,),
                    ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        physics: ScrollPhysics(),
                        itemCount: product.records1!.length,
                        itemBuilder: (BuildContext context,int index) {
                          return Container(
                            decoration: BoxDecoration(
                                border: Border(
                                  bottom:BorderSide(
                                      width: 1,color: kDarkTextColor
                                  ) ,
                                )
                            ),
                            child: ListTile(
                              title: Text("${product.records1![index].pname} ${product.records1![index].subPurity}K", style: listText),
                              subtitle: Text("${product.records1![index].subWeight} gm", style: largeListText),
                              trailing: Text("₹${product.records1![index].subPrice}", style: listText),
                            ),
                          );
                        }),
                 ],
               ),

                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width*1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text("Total : ₹${order.grandTotal}/-(approx)",style: largeListText,),
                        Text("With Making, HUID & GST Charge",style: largeListText,),
                        Text("24K Gold : ₹5000/gm",style: largeListText,),
                      ],
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10.0,horizontal: 10),
                  child: Container(
                    width: MediaQuery.of(context).size.width*1,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text("Term & Condition : Gold Rate will be fixed at the time of payment",style: TextStyle(fontSize: 14,color: kDarkTextColor),),

                      ],
                    ),
                  ),
                ),


              ],
            ),
          ),
        ),
      );

  }
}

