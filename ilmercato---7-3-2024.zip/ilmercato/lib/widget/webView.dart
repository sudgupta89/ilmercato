
import 'package:ilmercato/Api/ServerConstants.dart';
import 'package:ilmercato/main.dart';
import 'package:ilmercato/screens/home/components/home_header.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/material.dart';

import 'package:ilmercato/screens/cart/model/boxes.dart';

class WebView1 extends StatefulWidget {

  const WebView1({ Key? key}) : super(key: key);
  @override
  _WebViewExampleState createState() => _WebViewExampleState();
}

class _WebViewExampleState extends State<WebView1> {
  bool isLoading =true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: <Widget>[
          WebView(
            onWebResourceError: (WebResourceError webviewerrr) {
              print("Handle your Error Page here");
            },
            initialUrl: "${ServerConstants.paymentGatewayApi}${ShopCartsH().finalAmount.toStringAsFixed(3)}",
            javascriptMode: JavascriptMode.unrestricted,
            onPageFinished: (finish) {
              setState(() {
                isLoading = false;
              });
            },
          ),
          isLoading ? Center( child: CircularProgressIndicator(),)
              : Stack(),
        ],
      ),

      // floatingActionButton: FloatingActionButton(
      //   onPressed: (){},
      //       //displayModalBottomSheet(context),
      //   child: Icon(Icons.menu,color:Color(0xFF9e7207)),
      //   backgroundColor: Colors.white,
      // ),

    );
  }
  // void displayModalBottomSheet(context) {
  //
  //   showModalBottomSheet(
  //       context: context,
  //       builder: (BuildContext bc) {
  //         return Container(
  //           decoration: BoxDecoration(
  //             color: Colors.white,
  //           ),
  //           child: Categories(),
  //         );
  //       });
  // }
}