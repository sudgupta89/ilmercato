import 'package:flutter/material.dart';
import 'package:ilmercato/screens/sign_up/sign_up_screen.dart';
import '../../../constants.dart';

class NoAccountText extends StatelessWidget {
  const NoAccountText({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SizedBox(height: 20),

        SizedBox(height: 20),
       

      ],
    );
  }
}
