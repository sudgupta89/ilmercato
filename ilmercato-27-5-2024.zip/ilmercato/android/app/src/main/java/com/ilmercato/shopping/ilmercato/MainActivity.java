package com.ilmercato.shopping.ilmercato;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
