#import <Flutter/Flutter.h>
#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>

@interface RunnerTests : XCTestCase

@end

@implementation RunnerTests

- (void)testExample {
  // If you add code to the Runner application, consider adding tests here.
  // See https://developer.apple.com/documentation/xctest for more information about using XCTest.
}

@end
