enum MenuState { home, favourite, cart, profile }
