import 'package:flutter/material.dart';
import 'package:ilmercato/screens/dashboard/model/OrderGroup.dart';

class OrderList extends StatelessWidget {
  final Records orderList;
  const OrderList({Key? key,required this.orderList}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
