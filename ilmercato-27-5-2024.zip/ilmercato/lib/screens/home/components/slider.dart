import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class SliderA extends StatefulWidget {
  const SliderA({
    Key? key,
  }) : super(key: key);

  @override
  _SliderAState createState() => _SliderAState();
}

class _SliderAState extends State<SliderA> {

  @override
  Widget build(BuildContext context) {
      return CarouselSlider(
          options: CarouselOptions(
            viewportFraction: 2,
            enlargeCenterPage: false,
             autoPlay: true,
          ),
          items: imgList.map((item) => Container(
            width: MediaQuery.of(context).size.width*1,
            child: Center(
                child: Image.network("${item.toString()}", fit: BoxFit.cover)
            ),
          )).toList(),
        );
  }
}


final List<String> imgList = [

  'https://healthkart.online/imagefolder/lavazzabanner1.webp',

  'https://healthkart.online/imagefolder/lavazzabanner.webp',

  'https://healthkart.online/imagefolder/odkbanner.webp'
];

final List<Widget> imageSliders = imgList.map((item) => Container(

  child: ClipRRect(
      borderRadius: BorderRadius.all(Radius.circular(5.0)),
      child: Stack(
        children: <Widget>[
          Image.network(item, fit: BoxFit.cover,),
          Positioned(
            bottom: 0.0,
            left: 0.0,
            right: 0.0,
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color.fromARGB(200, 0, 0, 0),
                    Color.fromARGB(0, 0, 0, 0)
                  ],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
              ),
              padding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 20.0),
              child: Text(
                'No. ${imgList.indexOf(item)} image',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      )
  ),
)).toList();